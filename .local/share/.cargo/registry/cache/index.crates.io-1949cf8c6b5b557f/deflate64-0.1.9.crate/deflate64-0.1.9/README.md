Deflate64 implementation based on [.NET's implementation][dotnet-impl]

This is made to unzip zip file with deflate64 made with windows 11.

[dotnet-impl]: https://github.com/dotnet/runtime/tree/e5efd8010e19593298dc2c3ee15106d5aec5a924/src/libraries/System.IO.Compression/src/System/IO/Compression/DeflateManaged
