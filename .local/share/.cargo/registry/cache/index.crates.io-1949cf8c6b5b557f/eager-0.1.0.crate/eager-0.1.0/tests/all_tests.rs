//#![feature(trace_macros)] //trace_macros!(true);
#![recursion_limit="256"]
#[macro_use]
extern crate eager;

mod macros;
