proc-macro crate for [`attribute-derive`](https://lib.rs/attribute-derive)
