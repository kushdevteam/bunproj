#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Namespace {
  Html,
  Svg,
}
