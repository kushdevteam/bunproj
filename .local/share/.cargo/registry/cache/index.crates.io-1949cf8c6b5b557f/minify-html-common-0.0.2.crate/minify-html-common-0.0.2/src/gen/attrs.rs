include!(concat!(env!("OUT_DIR"), "/attrs.rs"));
