# DO NOT USE

This crate was merged into [async-lock], which provides the API this crate used to.

[async-lock]: https://crates.io/crates/async-lock
