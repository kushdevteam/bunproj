# outref

[![Latest Version]][crates.io]
[![Documentation]][docs.rs] 
![License]

Write-only references and slices.

[crates.io]: https://crates.io/crates/outref
[Latest Version]: https://img.shields.io/crates/v/outref.svg
[Documentation]: https://docs.rs/outref/badge.svg
[docs.rs]: https://docs.rs/outref
[License]: https://img.shields.io/crates/l/outref.svg

Documentation: <https://docs.rs/outref>
