<!-- TODO: Eventually this should be auto-generated -->

- [Unreleased](#unreleased)
  - [Added](#added)
  - [Changed](#changed)
  - [Removed](#removed)
  - [Fixed](#fixed)
- [0.2.0](#020)
  - [Added](#added-1)
- [0.2.1](#021)
  - [Added](#added-2)

# Unreleased 

## Added
## Changed
## Removed
## Fixed
## Security

# 0.2.0

## Added

    * [wackbyte](https://github.com/wackbyte) added `#[qualifiers]` attribute which unifies all kinds of items to which qualifiers can be applied.
    * [wackbyte](https://github.com/wackbyte) added `#[field_qualifiers]` attribute which applies qualifiers to all fields of the item.
    * [JohnScience](https://github.com/JohnScience) added a default feature `legacy_attrs` to allow the use of the legacy `#[fn_qualifiers]`, `#[mod_qualifiers]`, `#[named_field_qualifiers]`, and `#[struct_qualifiers]` attributes.
    * [JohnScience](https://github.com/JohnScience) started a changelog.

# 0.2.1

## Added

    * Added a note on legacy attributes to the README.

# 0.2.2

## Fixed

    * Fixed the warning about the unused `legacy` module.
