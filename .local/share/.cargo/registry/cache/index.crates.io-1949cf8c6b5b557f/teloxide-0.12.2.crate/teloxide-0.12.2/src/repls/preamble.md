REPLs are meant only for simple bots and rapid prototyping.
If you need to supply dependencies or describe more complex dispatch logic, please use [`Dispatcher`].
See also: ["Dispatching or REPLs?"](dispatching/index.html#dispatching-or-repls).

[`Dispatcher`]: crate::dispatching::Dispatcher

All errors from the handler and update listener will be logged.
