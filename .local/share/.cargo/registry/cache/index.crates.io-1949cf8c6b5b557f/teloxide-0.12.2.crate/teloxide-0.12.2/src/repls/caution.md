**DO NOT** use this function together with [`Dispatcher`] and other REPLs,
because Telegram disallow multiple requests at the same time from the same bot.
