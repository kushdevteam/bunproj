# Usage

```
$ RUST_LOG=info cargo run --features="full" --example <example-name>
```

Don't forget to initialise the `TELOXIDE_TOKEN` environmental variable.
