To stop a REPL, simply press `Ctrl`+`C` in the terminal where you run the program.
Note that graceful shutdown may take some time (we plan to improve this, see [#711]).

[#711]: https://github.com/teloxide/teloxide/issues/711
