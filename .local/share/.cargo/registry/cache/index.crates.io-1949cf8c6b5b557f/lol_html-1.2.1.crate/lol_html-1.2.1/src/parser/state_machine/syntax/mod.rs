#[macro_use]
mod text;

#[macro_use]
mod tag;

#[macro_use]
mod comment;

#[macro_use]
mod doctype;
