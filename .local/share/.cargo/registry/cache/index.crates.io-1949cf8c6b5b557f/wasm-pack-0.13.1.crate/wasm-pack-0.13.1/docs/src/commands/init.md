# wasm-pack init (DEPRECATED)

This command has been deprecated in favor of `build`, which does the same thing, but is
a much more representative name for the command. [Read the docs for `build`.][build]

[build]: ./build.html
