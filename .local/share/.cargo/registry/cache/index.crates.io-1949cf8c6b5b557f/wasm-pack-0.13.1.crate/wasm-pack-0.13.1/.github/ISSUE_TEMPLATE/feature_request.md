---
name: Feature Request 💡
about: Suggest a new idea for wasm-pack
---

## 💡 Feature description
Brief explanation of the requested feature.

#### 💻 Basic example
Include a basic code example if possible. Omit this section if not applicable.