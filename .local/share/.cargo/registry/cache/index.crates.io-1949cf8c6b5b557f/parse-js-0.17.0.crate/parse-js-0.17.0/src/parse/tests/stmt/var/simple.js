let a = 1, b;
