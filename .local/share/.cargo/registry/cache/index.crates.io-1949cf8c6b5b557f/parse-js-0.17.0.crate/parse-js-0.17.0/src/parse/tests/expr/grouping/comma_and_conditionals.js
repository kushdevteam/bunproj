(a, a ? b : c && d, d);
