!!++~abc?.def.ghi;
