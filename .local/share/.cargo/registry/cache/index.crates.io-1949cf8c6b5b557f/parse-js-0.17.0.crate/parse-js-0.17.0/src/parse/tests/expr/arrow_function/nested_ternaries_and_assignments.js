x = true ? (x) => x ? x : x : 5;
