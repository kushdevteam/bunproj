var set = {get: [set, get, await]}, of, {get, set, yield: [await, of]} = {await, of, let}, await = let, yield;
