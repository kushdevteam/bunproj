a ? b : c;
