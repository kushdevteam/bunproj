function* a() {
  yield 1;
}
