const f=d(void 0),y=t=>{const[e,n]=p(t.current());return h(()=>{const r=()=>n(t.current());return t.addListener(r),()=>t.removeListener(r)},[]),e}
