+new abc?.def();
