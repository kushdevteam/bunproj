<a.b.c x={1} y='a'>  a
  <bc1--:a4-3 xLa:z="a">{1}{2} {<  nu:a {...{a:b,c}} />}</bc1--:a4-3>
  a <red.a /> bb
    bb  <></>
</a.b.c>;
