# Changelog

## Version 0.13.0

- Bump `axum` support to 0.7
- Remove support for `actix-web 2.0`
- Add support for extracting form data in actix via `QsForm`
