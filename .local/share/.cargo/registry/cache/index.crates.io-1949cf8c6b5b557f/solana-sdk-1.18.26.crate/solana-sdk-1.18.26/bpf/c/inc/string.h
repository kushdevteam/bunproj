#pragma once
#include <solana_sdk.h>

#define memcpy sol_memcpy
#define memset sol_memset
#define strlen sol_strlen

