#pragma once
typedef void *FILE;

int printf(const char * restrictformat, ... );
