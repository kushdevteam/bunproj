#[deprecated(
    since = "1.15.0",
    note = "Please use `solana_connection_cache::nonblocking::client_connection::ClientConnection` instead."
)]
pub use solana_connection_cache::nonblocking::client_connection::ClientConnection as TpuConnection;
