//! Trunk's subcommands

pub mod build;
pub mod clean;
pub mod config;
pub mod core;
pub mod serve;
pub mod tools;
pub mod watch;
