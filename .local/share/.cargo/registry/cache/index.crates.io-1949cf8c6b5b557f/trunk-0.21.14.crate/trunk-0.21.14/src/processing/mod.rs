//! Functionality for processing

pub mod integrity;
pub mod minify;
