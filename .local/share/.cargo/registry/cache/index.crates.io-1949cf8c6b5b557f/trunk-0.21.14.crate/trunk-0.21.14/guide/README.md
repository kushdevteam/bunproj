# The book

## At least once

You'll need to install some pre-requisites in to work build the book:

```shell
cargo install mdbook --locked
cargo install mdbook-admonish --locked
mdbook-admonish install .
```

## When editing

```shell
mdbook serve
```
