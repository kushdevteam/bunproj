# Getting started
 
The following subsections explain what is required to install and use `trunk`, and how you can start with a basic
project.
